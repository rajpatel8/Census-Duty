import javax.swing.JFrame;
import javax.swing.JOptionPane;

import frontend.*;

public class Run_Me 
{
    public static void main(String[] args)
    {
        JFrame  f=new JFrame(); 
        JOptionPane.showMessageDialog(f,"Hello, Welcome to Project census"); 
        login a = new login();
        a.Login();
    }
}	