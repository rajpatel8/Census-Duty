This folder contains

1) package frontend - which is the pakage of our project.
2) Run_Me.java - this is the main java file to initialize/start the application.
3) mysql-connctor - to connect the Database with application.
4) readme.md.
