package frontend;

import java.awt.*;  
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import java.util.*;

public class username implements ActionListener
{
    JFrame  f=new JFrame(); 
    JFrame frame5 = new JFrame("Username");
    JLabel l =  new JLabel("Set Username and Password");
    JLabel l1 =  new JLabel("Username :");
    JLabel l2 =  new JLabel("Password :");
    JLabel l3 =  new JLabel("Confirm Password :");
    JLabel l4 =  new JLabel("");

    JTextArea t1 = new JTextArea();
    JPasswordField t2 = new JPasswordField();
    JPasswordField t3 = new JPasswordField() ;
    JButton bb = new JButton("Confirm");
    
    String t,s1,s2,s3 ;

    public void Username(String u ,String u1 ,String u2 ,String u3) 
    {
        l.setBounds(100,30,350,30);
        l.setFont(new Font("Serif", Font.BOLD, 21));
        
        l1.setBounds(50, 85, 120, 25);
        l1.setFont(new Font("Serif", Font.BOLD, 18));
        l2.setBounds(50, 140, 120, 25);
        l2.setFont(new Font("Serif", Font.BOLD, 18));
        l3.setBounds(50, 195, 200, 25);
        l3.setFont(new Font("Serif", Font.BOLD, 18));

        t1.setBounds(160, 85,120,25);
        t2.setBounds(157, 140, 120, 25);
        t3.setBounds(235, 195, 120, 25);
        bb.setBounds(170,250,120 ,25);
    
        t = u ;
        s1 = u1 ;
        s2 = u2 ;
        s3  = u3 ;
        frame5.add(l);
        frame5.add(l1); frame5.add(t1);
        frame5.add(l2); frame5.add(t2);
        frame5.add(l3); frame5.add(t3);
        frame5.add(bb);frame5.add(l4);
        l4.setVisible(false);
        frame5.setSize(500 , 400);
        frame5.setVisible(true);
        frame5.setLocationRelativeTo(null);
        bb.addActionListener(this);
       
    }
    @Override
    public void actionPerformed(ActionEvent e) 
    {
    	
        String uname = t1.getText();
        String pass = t2.getText();
        String passcom = t3.getText();
        if(Objects.equals(pass, passcom))
        {
         
        try 
        {
            String url = "jdbc:mysql://localhost:3306/census";
            String user = "root";
            String password = "00001934661";
            
            Connection connect = DriverManager.getConnection(url, user, password);
            
            PreparedStatement st =connect.prepareStatement("Select Username from users where Username=?");
            
            st.setString(1, uname);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(f, "Username Already taken");
            }
            else
            {
            	String query = "Insert INTO users values (' "+ t + "','"+ s1 + "','" + s2 + "','" + s3 + "','" +uname+"','"+ pass +"')";
                
                Statement s = connect.createStatement();
                
                int x = s.executeUpdate(query);

                if(x!=0)
                {
                	JOptionPane.showMessageDialog( f , "Account created, You will be redirected to login page." );
                    login r = new login();
                    r.Login();
                    frame5.dispose();
                }
            }
            connect.close();
        } 
        catch (Exception exception) 
        {
            exception.printStackTrace();
        }
        
        }
        else
        {
            JOptionPane.showMessageDialog( bb , "Passwords does't match" );            
        }

    }

}
