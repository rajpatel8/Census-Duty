package frontend;

import java.awt.*;  
import java.awt.event.*;
import javax.swing.*;

public class register implements ActionListener
{
    JFrame  f1 =new JFrame(); 
    JFrame frame4 = new JFrame("Register") ;
    JLabel l = new JLabel("New User");
    JLabel l1 = new JLabel("Name :") ;
    JLabel l2 = new JLabel("School id :") ;	
    JLabel l3 = new JLabel("Designation :") ;
    JLabel l4 = new JLabel("Gender :") ;
    
    JTextArea t1 = new JTextArea();
    JTextArea t2= new JTextArea();
    JTextArea t3 = new JTextArea();
    JRadioButton m = new JRadioButton("Male");
    JRadioButton f = new JRadioButton("Female");
    JButton r = new JButton("Register") ;
    
    public void Register() 
    {
        l.setBounds(200,30,120,30);
        l.setFont(new Font("Serif", Font.BOLD, 21));
        l1.setBounds(120,70,120,30);
        l1.setFont(new Font("Serif", Font.BOLD, 18));
        l2.setBounds(120,125,120,30);
        l2.setFont(new Font("Serif", Font.BOLD, 18));
        l3.setBounds(120,180,150,30);
        l3.setFont(new Font("Serif", Font.BOLD, 18));
        l4.setBounds(120,235,120,30);
        l4.setFont(new Font("Serif", Font.BOLD, 18));


        JLabel l7 = new JLabel();


        t1.setBounds(200, 70, 120, 25);
        t2.setBounds(220, 125, 120, 25);
        t3.setBounds(250, 180, 120, 25);
       
        m.setBounds(200,235,80,30);
        m.setFont(new Font("Serif", Font.BOLD, 18));

        f.setBounds(270,235,100,30);
        f.setFont(new Font("Serif", Font.BOLD, 18));

        ButtonGroup b =new ButtonGroup();
        b.add(m);b.add(f);

        
        r.setBounds(200,300,120,50);
        r.setFont(new Font("Serif", Font.BOLD, 18));

        frame4.add(l);
        frame4.add(l1); frame4.add(t1);
        frame4.add(l2); frame4.add(t2);
        frame4.add(l3); frame4.add(t3);
        frame4.add(l4); frame4.add(m);frame4.add(f);
        frame4.add(r);  frame4.add(l7);
        l7.setVisible(false);
        frame4.setVisible(true);
        frame4.setSize(500 , 500);
        frame4.setLocationRelativeTo(null);
        r.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        String Name = t1.getText() ;
        String School_id = t2.getText() ;
        String Designation = t3.getText() ;
        String Gender = "" ;
        if (m.isSelected()) 
        {
            Gender = m.getText();
        }
        else if(f.isSelected())
        {
            Gender = f.getText() ;
        }
        
        if(Name.length() == 0){
        	JOptionPane.showMessageDialog( f , "Please enter your Name" );
            t1.setBackground(Color.red);
          }
        else if(School_id.length() == 0){
        	JOptionPane.showMessageDialog( f , "Please enter your School_id" );
            t2.setBackground(Color.red);
          }
        else if(Designation.length() == 0){
        	JOptionPane.showMessageDialog( f , "Please enter your Designation" );
            t3.setBackground(Color.red);
          }
        else if(Gender.length() == 0){
        	JOptionPane.showMessageDialog( f , "Please select a gender " );
            l4.setBackground(Color.red);
          }
        else 
        	{
             username u = new username();
             u.Username(Name,School_id,Designation,Gender);	
             frame4.dispose();
        } 
    
        
    }
}