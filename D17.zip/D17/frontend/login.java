//Declaring Package
package frontend;

//importing Some useful classes
import java.awt.*;  
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

//Creadting a Class  to impliment ActionListener
public class login implements ActionListener
{
    // Creating Some Jfame, Buttons and Textboxs.
    JFrame  f1 =new JFrame(); 
    JFrame frame1 = new JFrame("Login") ;
    JButton b1 = new JButton("Login") ;
    JButton b2 = new JButton("Register");   
    JTextArea t = new JTextArea();
    JPasswordField p = new JPasswordField();

    //Creating method Login()
    public void Login()
    {
        // Setting the appearance of Jfram on screen
        frame1.setSize(300,275) ;
        frame1.setLocationRelativeTo(null);
        
        // Creating Lable and setting its appearance
        JLabel l = new JLabel("LOGIN") ;
        l.setBounds(123, 25 ,100,30);
        l.setFont(new Font("Serif", Font.PLAIN, 18));

        // Creating Lable and setting its appearance
        JLabel l1 = new JLabel("Username :") ;
        l1.setBounds(30,75,100,30);
        l1.setFont(new Font("Serif", Font.PLAIN, 18));
        
        // Creating Lable and setting its appearance
        JLabel l2 = new JLabel("Password :") ;
        l2.setBounds(30,130,100,30);
        l2.setFont(new Font("Serif", Font.PLAIN, 18));
        
        // setting appearance of Buttons
        b1.setBounds(150,185,80,30);
        b1.setFont(new Font("Serif", Font.PLAIN, 18));

        // setting appearance of Buttons
        b2.setBounds(50,185, 100, 30);
        b2.setFont(new Font("Serif", Font.PLAIN, 18));

        // setting appearance of PasswordBox
        p.setBounds(140, 130, 130, 30);
        
        // setting appearance of TextBox
        t.setBounds(140, 75, 130, 30);

        //Adding all the components to Main-Jframe
        frame1.add(l);
        frame1.add(l1);
        frame1.add(l2);
        frame1.add(p);
        frame1.add(t);
        frame1.add(b1);
        frame1.add(b2);
        frame1.setLayout(null);
        frame1.setVisible(true);
        
        //Adding Listner on the buttons
        b1.addActionListener(this);
        b2.addActionListener(this);
    }
    
    // Overiding the method actionPerformed 
    @Override
    public void actionPerformed(ActionEvent e) 
    {
    	//Getting the source of event
        if(e.getSource()==b1)
        {   
            //Storing the data which is enterd in textfield and password field into Strings        
        	String Username = t.getText();
            String Password = p.getText();

            // check if username is empty 
            if(Username.length() == 0){
            	JOptionPane.showMessageDialog( f1 , "Please enter your Username" );
                t.setBackground(Color.red);
              }
            // check if Password is empty 
            else if (Password.length()==0)
            {
            	JOptionPane.showMessageDialog( f1 , "Please enter your Password" );
                p.setBackground(Color.red);
            }
            // If all things are set we can connect to our Datbase
            else {
        // Using try-catch to connect to Database and execute the query
        try 
        {   
            Class.forName("com.mysql.cj.jdbc.Driver");

            String url = "jdbc:mysql://localhost/census";
            String user = "root";
            String password = "00001934661";
            
            Connection connect = DriverManager.getConnection(url, user, password);

            PreparedStatement st = connect.prepareStatement("Select Username, password from users where Username=? and password=?");
            
            st.setString(1, Username);
            st.setString(2, Password);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                frame1.dispose(); // Disposing Current frame
                home h = new home(); // Redirecting user to Main page
                h.Insert();
                JOptionPane.showMessageDialog(f1, "You have successfully logged in");
            }
            else
            {
            	JOptionPane.showMessageDialog(f1, "You have enterd wrong Username or Password");
            }
            connect.close();           
        } 
        catch (Exception exception) 
        {
            exception.printStackTrace();
        }
            }
        }
        
        if(e.getSource()==b2)
        {
            register r = new register() ;
            r.Register();
            frame1.dispose();
        }

    }
}    