package frontend;

import java.awt.*;  
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import java.util.*;

public class home implements ActionListener{
    JFrame  f=new JFrame(); 
    JFrame frame2 = new JFrame("Census DataBase") ;
    JMenuBar mb = new JMenuBar() ;
    JButton mb1 =new JButton("Insert");
    JButton mb2 = new JButton("Update") ;
    JButton mb3 = new JButton("Logout") ;
    JButton b1 = new JButton("Insert") ;
    JTextArea t1 = new JTextArea();
    JTextArea t2 = new JTextArea();
    JTextArea t3 = new JTextArea();
    JTextArea t4 = new JTextArea();
    JTextArea t5 = new JTextArea();
    JTextArea t6 = new JTextArea();
    JTextArea t7 = new JTextArea();
    JTextArea t8 = new JTextArea();
    public void Insert()
    {
        frame2.setSize(500, 600);
        frame2.setLocationRelativeTo(null);
        mb.add(mb1);
        mb.add(mb2);
        mb.add(mb3);

        JLabel l1 = new JLabel("Location ID :") ;
        l1.setBounds(80,20,180,30);
        l1.setFont(new Font("Serif", Font.BOLD, 18));

        JLabel l2 = new JLabel("Location Name :") ;
        l2.setBounds(80,75,180,30);
        l2.setFont(new Font("Serif", Font.BOLD, 18));

        JLabel l3 = new JLabel("District :") ;
        l3.setBounds(80,130,180,30);
        l3.setFont(new Font("Serif", Font.BOLD, 18));

        JLabel l4 = new JLabel("City :") ;
        l4.setBounds(80,185,180,30);
        l4.setFont(new Font("Serif", Font.BOLD, 18));

        JLabel l5 = new JLabel("House ID :") ;
        l5.setBounds(80,240,180,30);
        l5.setFont(new Font("Serif", Font.BOLD, 18));

        JLabel l6 = new JLabel("House Name :") ;
        l6.setBounds(80,295,180,30);
        l6.setFont(new Font("Serif", Font.BOLD, 18));

        JLabel l7 = new JLabel("Owner Name :") ;
        l7.setBounds(80,350,180,30);
        l7.setFont(new Font("Serif", Font.BOLD, 18));

        JLabel l8 = new JLabel("Number of People :") ;
        l8.setBounds(80,405,180,30);
        l8.setFont(new Font("Serif", Font.BOLD, 18));

        
        b1.setBounds(60,460,120,50);
        b1.setFont(new Font("Serif", Font.BOLD, 18));

        
        t1.setBounds(255, 20, 200, 30);
        t2.setBounds(255, 75, 200, 30);
        t3.setBounds(255, 130, 200, 30);
        t4.setBounds(255, 185, 200, 30);
        t5.setBounds(255, 240, 200, 30);
        t6.setBounds(255, 295, 200, 30);
        t7.setBounds(255, 350, 200, 30);       
        t8.setBounds(255, 405, 200, 30);
        
        frame2.setJMenuBar(mb);
        frame2.add(l1);frame2.add(t1);
        frame2.add(l2);frame2.add(t2);
        frame2.add(l3);frame2.add(t3);
        frame2.add(l4);frame2.add(t4);
        frame2.add(l5);frame2.add(t5);
        frame2.add(l6);frame2.add(t6);
        frame2.add(l7);frame2.add(t7);
        frame2.add(l8);frame2.add(t8);
        frame2.add(b1);
        frame2.setLayout(null);
        frame2.setVisible(true);
        b1.addActionListener(this);
        mb1.addActionListener(this);
        mb2.addActionListener(this);
        mb3.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
      if(e.getSource()==mb3)
      {
        frame2.dispose();
        login L = new login();
        L.Login();
      }
      if(e.getSource()== mb1)
      {
        frame2.dispose();
        Insert();
      }
      if (e.getSource()==b1) 
      {
        String location_id=t1.getText() ;
        String location_name= t2.getText();
        String district = t3.getText();
        String city = t4.getText();
        String house_id = t5.getText();
        String house_name = t6.getText();
        String owner_Name = t7.getText() ;
        String num_of_pep = t8.getText() ;
        
        try 
        {
            String url = "jdbc:mysql://localhost:3306/census";
            String user = "root";
            String password = "00001934661";
            
            Connection connect = DriverManager.getConnection(url, user, password);

            String query = "Insert INTO location values (' "+ location_id + "','"+ location_name + "','" + district + "','" + city + "')";    
            String query2 = " Insert INTO house values('"+ house_id + "','" + house_name  + "','" + owner_Name + "'," + num_of_pep +")" ;
            Statement s = connect.createStatement();
            
            PreparedStatement st =  connect
                    .prepareStatement("Select * from location where location_id=? and location_name=? and district=? and city=?");
            
            st.setString(1, location_id);
            st.setString(2, location_name);
            st.setString(3, district);
            st.setString(4, city);
            ResultSet rs = st.executeQuery();
            if(rs.next())
            {
            	s.executeUpdate(query);
              s.executeUpdate(query2);
              JOptionPane.showMessageDialog( f , "Data Inserted Successfully" );            	
            }
           
            else
            {
            	s.executeUpdate(query2);
            	JOptionPane.showMessageDialog( f , "Data Inserted Successfully" );
            	
            }
            rs.close();
            connect.close();
        } 	
        catch (Exception exception) 
        {
            exception.printStackTrace();
        }
        
      }
      if(e.getSource()== mb2)
      {
        frame2.dispose();
        update u = new update();
        u.Update();
      }
    }

}