package frontend;

import java.awt.*;  
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import java.util.*;

public class update implements ActionListener 
{
    JFrame  f=new JFrame(); 
    JFrame frame3 = new JFrame("Update DataBase") ;
    JMenuBar mb = new JMenuBar() ;
    JButton mb1 =new JButton("Insert");
    JLabel l1 = new JLabel("Location ID :") ;
    JLabel l2 = new JLabel("Location Name :") ;
    JLabel l3 = new JLabel("District :") ;
    JLabel l4 = new JLabel("City :") ;
    JLabel l5 = new JLabel("House ID :") ;
    JLabel l6 = new JLabel("House Name :") ;
    JLabel l7 = new JLabel("Owner Name :") ;
    JLabel l8 = new JLabel("Number of People :") ;
    
    JTextArea t1 = new JTextArea();
    JTextArea t2 = new JTextArea();
    JTextArea t3 = new JTextArea();
    JTextArea t4 = new JTextArea();
    JTextArea t5 = new JTextArea();
    JTextArea t6 = new JTextArea();
    JTextArea t7 = new JTextArea();
    JTextArea t8 = new JTextArea();
    JButton b1 = new JButton("Update");
    
    public void Update() 
    {
        t1.setBounds(260, 20, 200, 30);       
        t2.setBounds(260, 75, 200, 30);     
        t3.setBounds(260, 130, 200, 30);       
        t4.setBounds(260, 185, 200, 30);        
        t5.setBounds(260, 240, 200, 30);        
        t6.setBounds(260, 295, 200, 30);        
        t7.setBounds(260, 350, 200, 30);        
        t8.setBounds(260, 405, 200, 30);
        b1.setBounds(150, 460,200 ,50);
        b1.setFont(new Font("Serif", Font.BOLD, 18));
 
        l1.setBounds(80,20,180,30);
        l1.setFont(new Font("Serif", Font.BOLD, 18));
        l2.setBounds(80,75,180,30);
        l2.setFont(new Font("Serif", Font.BOLD, 18));
        l3.setBounds(80,130,180,30);
        l3.setFont(new Font("Serif", Font.BOLD, 18));
        l4.setBounds(80,185,180,30);
        l4.setFont(new Font("Serif", Font.BOLD, 18));
        l5.setBounds(80,240,180,30);
        l5.setFont(new Font("Serif", Font.BOLD, 18));
        l6.setBounds(80,295,180,30);
        l6.setFont(new Font("Serif", Font.BOLD, 18));
        l7.setBounds(80,350,180,30);
        l7.setFont(new Font("Serif", Font.BOLD, 18));
        l8.setBounds(80,405,180,30);
        l8.setFont(new Font("Serif", Font.BOLD, 18));

        JLabel l9 = new JLabel();
        mb.add(mb1);
        frame3.setJMenuBar(mb);       
        frame3.add(l1);frame3.add(t1);
        frame3.add(l2);frame3.add(t2);
        frame3.add(l3);frame3.add(t3);
        frame3.add(l4);frame3.add(t4);
        frame3.add(l5);frame3.add(t5);
        frame3.add(l6);frame3.add(t6);
        frame3.add(l7);frame3.add(t7);
        frame3.add(l8);frame3.add(t8);
        frame3.add(b1);frame3.add(l9);
        frame3.setLayout(null);
        frame3.setVisible(true);
        b1.addActionListener(this);
        mb1.addActionListener(this);
        frame3.setSize(500, 600);
        frame3.setLocationRelativeTo(null);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) 
    {
       if(e.getSource()==b1) {String location_id=t1.getText() ;
        String location_name= t2.getText();
        String district = t3.getText();
        String city = t4.getText();
        String house_id = t5.getText();
        String house_name = t6.getText();
        String owner_Name = t7.getText() ;
        String num_of_pep = t8.getText() ;
        
        try 
        {
            String url = "jdbc:mysql://localhost:3306/census";
            String user = "root";
            String password = "00001934661";
            
            Connection connect = DriverManager.getConnection(url, user, password);

            String query = "Update data house_id='"+ house_id + "'," + "house_name='"+ house_name +"'," + "owner_Name='"+ owner_Name +"'," + "num_of_pep='"+ num_of_pep +"' where location_id='" +location_id +"' and location_name='"+location_name+"' and district='"+district+"'and city='"+city;                                                              
            
            Statement s = connect.createStatement();

            int x = s.executeUpdate(query);
            if(x==0)  
            {
                JOptionPane.showMessageDialog(f , "This location does't exist" );
            }
            else
            {
                JOptionPane.showMessageDialog(f , "Data updated Successfully" );
                
            }
            connect.close();
        } 
        catch (Exception exception) 
        {
            exception.printStackTrace();
        }
        
        frame3.dispose();
        home h1 = new home();
        h1.Insert(); }

        else if(e.getSource()==mb1)
        {
            frame3.dispose();
            home h1 = new home();
            h1.Insert(); 
        }
    }

}
